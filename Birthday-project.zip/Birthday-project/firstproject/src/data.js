export default[
    {
        SNO : 1,
        NAME : "UNNATI JAIN",
        BIRTHDAY : "8-NOVEMBER",
        Image : "https://cakewithname.net/pic-preview/Unnati/123/0/beautiful-best-birthday-cake-for-Unnati.jpg",
    },
    {
        SNO : 2,
        NAME : "AVNI JAIN",
        BIRTHDAY : "26-MARCH",
        Image : "https://mynamepix.com/names/images/happy-birthday-avni_35485b9666.jpg",
    },
    {
        SNO : 3,
        NAME : "ANSH GARG",
        BIRTHDAY : "3-APRIL",
        Image : "http://mynamepixs.com/result_display.php?id=2220&name=Ansh&name2=",
    },
    {
        SNO : 4,
        NAME : "ANJALI GARG",
        BIRTHDAY : "27-JANUARY",
        Image : "https://i.pinimg.com/736x/29/e8/4e/29e84e6f38ef56eab3c47d0b7c082864.jpg",
    },  
];